// version info
#define CHAI3D_DESCRIPTION     "Haptic Simulation Framework"
#define CHAI3D_VERSION_MAJOR   3
#define CHAI3D_VERSION_MINOR   3
#define CHAI3D_VERSION_PATCH   0
#define CHAI3D_PRERELEASE      ""
#define CHAI3D_METADATA        "+g9f2e2b0b2"
#define CHAI3D_VERSION         "3.3.0"
#define CHAI3D_VERSION_FULL    "3.3.0+g9f2e2b0b2"
#define CHAI3D_REVISION        0x9f2e2b0b2
